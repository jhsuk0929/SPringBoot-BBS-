package com.bbs.web.DAO.Mybatis;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bbs.web.DAO.BbsDAO;
import com.bbs.web.Entity.Bbs;

@Repository
public class MyBatisBbsDAO implements BbsDAO {

	private BbsDAO mapper;
	
	@Autowired
	public MyBatisBbsDAO(SqlSession sqlSession) {
		mapper =sqlSession.getMapper(BbsDAO.class);
	}
	@Override
	public ArrayList <Bbs> getList(String field, int pageNumber, int limit, String sortType, String searchWord){
		// TODO Auto-generated method stub
		return mapper.getList(field, pageNumber,limit, sortType, searchWord);
	}

	@Override
	public int deleteBbs(int bbsID) {
		// TODO Auto-generated method stub
		return mapper.deleteBbs(bbsID);
	}

	@Override
	public int updateBbs(int bbsID, String bbsTitle, String bbsContent) {
		// TODO Auto-generated method stub
		return mapper.updateBbs(bbsID, bbsTitle, bbsContent);
	}

	@Override
	public int count(String field,String searchWord) {
		// TODO Auto-generated method stub
		return mapper.count(field, searchWord);
	}
	@Override
	public int write(int bbsID ,  String bbsTitle, String userID, String bbsDate, String bbsContent) {
		// TODO Auto-generated method stub
		return  mapper.write(bbsID, bbsTitle, userID, bbsDate, bbsContent);
	}
	@Override
	public int getBbsID() {
		// TODO Auto-generated method stub
		return mapper.getBbsID() + 1;
	}
	@Override
	public Bbs getBbs(int bbsID) {
		// TODO Auto-generated method stub
		return mapper.getBbs(bbsID);
	}

}
