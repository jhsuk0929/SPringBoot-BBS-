package com.bbs.web.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bbs.web.DAO.UserDAO;
import com.bbs.web.Entity.User.User;

@Service
public class UserServiceimp implements UserService{
	@Autowired
	private UserDAO userDAO;

	@Override
	public User Login(String userID, String userPassword) {
		// TODO Auto-generated method stub
		return userDAO.Login(userID, userPassword);
	}


	@Override
	public int Join(String userID, String userPassword, String userName,
			String userGender, String userEmail) {
		// TODO Auto-generated method stub
		userDAO.Join(userID, userPassword, userName, userGender, userEmail );
		return 1;
	}


	@Override
	public int JoinCheck(String userID, String userPassword, String userName, String userGender, String userEmail) {
		// TODO Auto-generated method stub
		return userDAO.JoinCheck(userID, userPassword, userName, userGender, userEmail);
	}
	
}
