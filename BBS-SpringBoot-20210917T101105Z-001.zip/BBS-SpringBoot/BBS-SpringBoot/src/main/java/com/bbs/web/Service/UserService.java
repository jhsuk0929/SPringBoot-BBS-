package com.bbs.web.Service;

import com.bbs.web.Entity.User.User;

public interface UserService {

	
	//회원 관리 기능
	User Login(String userID, String userPassword);
	
	int Join(String userID, String userPassword, String userName,
			String userGender, String userEmail);
	int JoinCheck(String userID, String userPassword, String userName,
			String userGender, String userEmail);
}

