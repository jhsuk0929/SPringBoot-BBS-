package com.bbs.web.Controller.DetailController;

import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bbs.web.Entity.Bbs;
import com.bbs.web.Entity.Reply;
import com.bbs.web.Service.BbsService;
import com.bbs.web.Service.ReplyService;

@Controller
public class DetailController {
	@Autowired
	private BbsService service;
	@Autowired
	private ReplyService service2;

	@GetMapping("/detail")
	public String detailGet(Model model, HttpServletRequest request, @RequestParam(value="bbsID", required = true) int bbsID, @RequestParam(value="replyPage", required = false, defaultValue = "1") int replyPage) {
		//세션
		String checkSession =(String) request.getSession().getAttribute("userid");
		if(checkSession != null) {
			model.addAttribute("check", checkSession);
		}	
		
		
		//게시판 글 (1개) 보기
		Bbs detail = service.getBbs(bbsID);
		
		String bbsTitle = detail.getBbsTitle();
		String bbsContent = detail.getBbsContent();
		String userID = detail.getUserID();
		Date date = detail.getBbsDate();


		//댓글 리스트(1개의 글에 대한) 가져오기
		int limit = (replyPage -1) *3;
		ArrayList <Reply> list = service2.getList(bbsID, limit);
		
		
		//댓글 페이지 이동 버튼
		ArrayList<Integer> buttons = service2.replyButtonPaging(replyPage);
	
		
		int total = service2.countReply(bbsID);
		int totalPage = 0;
		if(total%3==0) {
			totalPage = total/3;
		}else {
			totalPage = total/3 +1;
		}
		
		
		
		model.addAttribute("bbsTitle", bbsTitle);
		model.addAttribute("bbsContent", bbsContent);
		model.addAttribute("userID", userID);
		model.addAttribute("date", date);
		model.addAttribute("bbsID", bbsID);
		model.addAttribute("replyList", list);
		model.addAttribute("buttons", buttons);
		model.addAttribute("replyPage", replyPage);
		model.addAttribute("totalPage", totalPage);
		model.addAttribute("total", total);

		return "detail";
	}
	
	
	

}
