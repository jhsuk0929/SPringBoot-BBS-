package com.bbs.web.Service;

import java.util.ArrayList;

import com.bbs.web.Entity.Bbs;

public interface BbsService {

	ArrayList <Bbs> getList(String field, int pageNumber, int limit, String sortType, String searchWord);

	
	int count(String field,String searchWord);

	int getBbsID();
	
	ArrayList <Integer> getheader(int pageNumber);
	
	ArrayList <Integer> buttonPaging(int PageNumber);
	
	int write( int bbsID, String bbsTitle, String userID, String bbsDate, String bbsContent);
	
	int deleteBbs(int bbsID);
	
	int updateBbs(int bbsID, String bbsTitle, String bbsContent);
	
	Bbs getBbs(int bbsID);
	
}
