package com.bbs.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//triggers auto-configuration and component scanning.
public class BbsSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BbsSpringBootApplication.class, args);
	}

}
