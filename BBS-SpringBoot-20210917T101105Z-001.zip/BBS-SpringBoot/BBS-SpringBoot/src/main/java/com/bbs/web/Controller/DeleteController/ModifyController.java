package com.bbs.web.Controller.DeleteController;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bbs.web.Service.BbsService;

@Controller
public class ModifyController {

	@Autowired
	BbsService service;

	@PostMapping("delete")
	public String deleteBbs(Model model, HttpServletRequest request,
			@RequestParam(value="bbsID", required = true) int bbsID
			) {
		//세션
		String checkSession =(String) request.getSession().getAttribute("userid");
		if(checkSession != null) {
			model.addAttribute("check", checkSession);
		}

		service.deleteBbs(bbsID);
		System.out.println("Bbs with BbsID: "+ bbsID+" deleted");
		return "redirect:Bbs";
	}


	@PostMapping("update")
	public String UpdateBbs(Model model, HttpServletRequest request, @RequestParam(value="bbsID", required = true) int bbsID
			,@RequestParam(value="bbsTitle", required = true)String bbsTitle, @RequestParam(value="bbsContent", required = true)String bbsContent
			) {
		String checkSession =(String) request.getSession().getAttribute("userid");
		if(checkSession != null) {
			model.addAttribute("check", checkSession);
		}

		service.updateBbs(bbsID, bbsTitle, bbsContent);
		System.out.println("Bbs with BbsID: "+ bbsID+" updated");
		return "redirect:detail?bbsID="+bbsID;

	}
}
