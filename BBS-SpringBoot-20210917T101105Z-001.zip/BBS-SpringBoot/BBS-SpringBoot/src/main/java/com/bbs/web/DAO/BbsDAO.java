package com.bbs.web.DAO;

import java.util.ArrayList;

import com.bbs.web.Entity.Bbs;

public interface BbsDAO {
	// 게시판 글 기능
		//조회
	ArrayList <Bbs> getList(String field, int pageNumber, int limit, String sortType, String searchWord );
		//삭제
	int deleteBbs(int bbsID);
		//수정
	int updateBbs(int bbsID, String bbsTitle, String bbsContent);
	
	int count(String field,String searchWord);
	
	int getBbsID();
	
	int write(int bbsID ,  String bbsTitle, String userID, String bbsDate, String bbsContent);
	
	Bbs getBbs(int bbsID);
	
	
	
	

}
