package com.bbs.web.DAO;

import java.util.ArrayList;

import com.bbs.web.Entity.Reply;

public interface ReplyDAO {
ArrayList <Reply> getList(int bbsID, int limit);
	
	int countReply(int bbsID);
	
	int writeReply(int replyID, int bbsID, String replyContent, String userID, String replyDate, int replyAvailable);
	
	int deleteReply(int replyID);
	
	int updateReply(int replyID, String updateContent);
	
	Reply getReply(int replyID);

	int getReplyID();

}
