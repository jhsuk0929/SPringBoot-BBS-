package com.bbs.web.Service;

import java.util.ArrayList;

import com.bbs.web.Entity.Reply;

public interface ReplyService {
	ArrayList <Reply> getList(int bbsID, int limit);
	
	int countReply(int bbsID);
	
	int writeReply(int replyID, int bbsID, String replyContent, String userID, String replyDate, int replyAvailable);
	
	int deleteReply(int replyID);
	
	int updateReply(int replyID, String updateContent);
	
	int getReplyID();
	
	ArrayList <Integer> replyButtonPaging(int PageNumber);

}
