package com.bbs.web.Service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bbs.web.DAO.ReplyDAO;
import com.bbs.web.Entity.Reply;

@Service
public class ReplyServiceimp implements ReplyService{
	
	@Autowired
	private ReplyDAO replydao;
	
	@Override
	public ArrayList<Reply> getList(int bbsID, int limit) {
		// TODO Auto-generated method stub
		return replydao.getList(bbsID, limit);
	}

	@Override
	public int countReply(int bbsID) {
		// TODO Auto-generated method stub
		return replydao.countReply(bbsID);
	}

	@Override
	public int writeReply(int replyID, int bbsID, String replyContent, String userID, String replyDate,
			int replyAvailable) {
		// TODO Auto-generated method stub
		return replydao.writeReply(replyID, bbsID, replyContent, userID, replyDate, replyAvailable);
	}

	@Override
	public int deleteReply(int replyID) {
		// TODO Auto-generated method stub
		return replydao.deleteReply(replyID);
	}

	@Override
	public int updateReply(int replyID, String updateContent) {
		// TODO Auto-generated method stub
		return replydao.updateReply(replyID, updateContent);
	}

	@Override
	public int getReplyID() {
		// TODO Auto-generated method stub
		int result = replydao.getReplyID() + 1;
		return result;
	}
	
	@Override
	public ArrayList<Integer> replyButtonPaging(int pageNumber) {
		// TODO Auto-generated method stub
		ArrayList <Integer> buttonHeader = new ArrayList <Integer> ();
		int standard = 3;
		if(pageNumber>standard) {
			while (true) {
				standard = standard +3;
				if (pageNumber<=standard) {
					break;
				}
			}
		}
		for (int i = standard -2; i<=standard; i++) {
		buttonHeader.add(i);
		}
		
		
		
		return buttonHeader;
	}

}
