package com.bbs.web.DAO;

import com.bbs.web.Entity.User.User;

public interface UserDAO {

	
	//회원 관리 기능
	User Login(String userID, String userPassword);
	
	int Join(String userID, String userPassword, String userName,
			String userGender, String userEmail);

	int JoinCheck(String userID, String userPassword, String userName, String userGender, String userEmail);
}
