package com.bbs.web.Service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bbs.web.DAO.BbsDAO;
import com.bbs.web.Entity.Bbs;

@Service
public class BbsServiceimp implements BbsService{

	@Autowired
	private BbsDAO bbsdao;
	
	@Override
	public ArrayList <Bbs> getList(String field, int pageNumber, int limit, String sortType, String searchWord){
		// TODO Auto-generated method stub
		bbsdao.getList(field, pageNumber, limit, sortType,  searchWord);
		
		return bbsdao.getList(field, pageNumber, limit, sortType,  searchWord);
	}



	@Override
	public int count(String field,String searchWord) {
		// TODO Auto-generated method stub
		return bbsdao.count(field, searchWord);
	}

	@Override
	public int getBbsID() {
		// TODO Auto-generated method stub
		
		return bbsdao.getBbsID();
	}
	
	@Override
	public ArrayList <Integer> getheader(int pageNumber){
		ArrayList <Integer> header = new ArrayList <Integer> ();
		ArrayList <Integer> realHeader = new ArrayList <Integer> ();

		for (int i=pageNumber*5; i>=(pageNumber*5)-4; i--) {
			header.add(i);
			}
			for (int e =4 ; e>=0; e--) {
				realHeader.add(header.get(e));
			}
			return realHeader;

		}


	@Override
	public int write(int bbsID ,  String bbsTitle, String userID, String bbsDate, String bbsContent) {
		// TODO Auto-generated method stub
		return bbsdao.write(bbsID, bbsTitle, userID, bbsDate, bbsContent);
	}

	@Override
	public ArrayList<Integer> buttonPaging(int pageNumber) {
		// TODO Auto-generated method stub
		ArrayList <Integer> buttonHeader = new ArrayList <Integer> ();
		int standard = 5;
		if(pageNumber>standard) {
			while (true) {
				standard = standard +5;
				if (pageNumber<=standard) {
					break;
				}
			}
		}
		for (int i = standard -4; i<=standard; i++) {
		buttonHeader.add(i);
		}
		return buttonHeader;
	}

	@Override
	public Bbs getBbs(int bbsID) {
		
		return bbsdao.getBbs(bbsID);
	}



	@Override
	public int deleteBbs(int bbsID) {
		// TODO Auto-generated method stub
		return bbsdao.deleteBbs(bbsID);
	}
	@Override
	public int updateBbs(int bbsID, String bbsTitle, String bbsContent) {
		// TODO Auto-generated method stub
		return bbsdao.updateBbs(bbsID, bbsTitle, bbsContent);
	}

	
	
}
