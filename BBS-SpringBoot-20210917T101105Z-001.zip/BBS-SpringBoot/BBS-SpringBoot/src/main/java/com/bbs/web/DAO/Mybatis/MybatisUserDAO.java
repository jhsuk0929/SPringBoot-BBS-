package com.bbs.web.DAO.Mybatis;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bbs.web.DAO.UserDAO;
import com.bbs.web.Entity.User.User;


@Repository
public class MybatisUserDAO implements UserDAO{
	
	
	private UserDAO mapper;

	
	@Autowired
	public MybatisUserDAO(SqlSession sqlSession) {
		mapper =sqlSession.getMapper(UserDAO.class);
	}
	
	@Override
	public User Login(String userID, String userPassword) {
		// TODO Auto-generated method stub
		return mapper.Login(userID, userPassword);
	}


	@Override
	public int Join(String userID, String userPassword, String userName,
			String userGender, String userEmail) {
		// TODO Auto-generated method stub
		
		return mapper.Join(userID, userPassword, userName, userGender, userEmail);
	}

	@Override
	public int JoinCheck(String userID, String userPassword, String userName, String userGender, String userEmail) {
		// TODO Auto-generated method stub
		return mapper.JoinCheck(userID, userPassword, userName, userGender, userEmail);
	}

}
