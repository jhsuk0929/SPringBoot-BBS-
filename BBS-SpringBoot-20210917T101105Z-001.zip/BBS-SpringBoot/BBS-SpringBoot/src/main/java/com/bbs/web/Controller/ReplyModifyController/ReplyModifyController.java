package com.bbs.web.Controller.ReplyModifyController;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bbs.web.Service.ReplyService;

@Controller
public class ReplyModifyController {
	@Autowired
	private ReplyService service;

	@PostMapping("deleteReply")
	public String deleteReply(Model model, HttpServletRequest request,
			@RequestParam(value = "bbsID", required = true) int bbsID,
			@RequestParam(value = "replyPage", required = true) int replyPage,
			@RequestParam(value = "replyID", required = true) int replyID) {

		String checkSession = (String) request.getSession().getAttribute("userid");
		if (checkSession != null) {
			model.addAttribute("check", checkSession);
		}

		service.deleteReply(replyID);

		return "redirect:detail?bbsID=" + bbsID + "&replyPage=" + replyPage;
	}

	@PostMapping("replyUpdate")
	public String updateReply(Model model, HttpServletRequest request,
			@RequestParam(value = "bbsID", required = true) int bbsID,
			@RequestParam(value = "replyPage", required = true) int replyPage,
			@RequestParam(value = "replyID", required = true) int replyID,
			@RequestParam(value = "updateContent", required = true) String updateContent) {

		String checkSession = (String) request.getSession().getAttribute("userid");
		if (checkSession != null) {
			model.addAttribute("check", checkSession);
		}

		service.updateReply(replyID, updateContent);

		return "redirect:detail?bbsID=" + bbsID + "&replyPage=" + replyPage;
	}

}
