package com.bbs.web.Controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {


	@GetMapping("/index")
	public String Home(Model model, HttpServletRequest request) {
		String checkSession =(String) request.getSession().getAttribute("userid");
		if(checkSession != null) {
			model.addAttribute("check", checkSession);
			System.out.println(checkSession);
		}
		return "Home";
	}
	@GetMapping("/Join")
	public String Join() {

		return "Join";
	}
	@GetMapping("/Login")
	public String Login() {

		return"Login";
	}

}
