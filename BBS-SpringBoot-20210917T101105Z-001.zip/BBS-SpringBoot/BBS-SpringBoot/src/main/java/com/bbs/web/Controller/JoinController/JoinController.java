package com.bbs.web.Controller.JoinController;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bbs.web.Service.UserService;

@Controller
public class JoinController {

	@Autowired
	private UserService userService;

	@PostMapping("JoinController")
	public String join( Model model, HttpServletRequest request, @RequestParam(value="userid", required = true) String userID
			, @RequestParam(value="userpassword", required = true) String userPassword, @RequestParam(value="name", required = true) String userName
			, @RequestParam(value="gender", required = true) String userGender, @RequestParam(value="email", required = true) String userEmail			
			) throws IOException {

		int checkjoin = userService.JoinCheck(userID, userPassword, userName, userGender, userEmail);

		String result = null;
		if( checkjoin  == 0) {
			userService.Join(userID, userPassword, userName, userGender, userEmail);
			String joinokay = "okay";
			model.addAttribute("joinokay", joinokay);
			result = "Login";	
		}else {
			String JoinFail = "fail";
			model.addAttribute("JoinFail", JoinFail);
			result = "Join";
		}
		return result;
	}
}

