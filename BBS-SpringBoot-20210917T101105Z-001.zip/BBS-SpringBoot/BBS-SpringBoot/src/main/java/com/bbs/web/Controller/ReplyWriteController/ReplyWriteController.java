package com.bbs.web.Controller.ReplyWriteController;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bbs.web.Service.ReplyService;
@Controller
public class ReplyWriteController {
	@Autowired
	private ReplyService service;


	@PostMapping("replyWrite")
	public String replyWrite (Model model, HttpServletRequest request, @RequestParam(value="bbsID", required = true) int bbsID
			, @RequestParam(value="replyContent", required = true) String replyContent) {

		String checkSession =(String) request.getSession().getAttribute("userid");
		if(checkSession != null) {
			model.addAttribute("check", checkSession);
		}

		String userID = (String) request.getSession().getAttribute("userid");

		int replyID = service.getReplyID();

		Date replyDate1 =  new Date();
		String pattern = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat formatter = new SimpleDateFormat(pattern);
		String replyDate = formatter.format(replyDate1);
		int replyAvailable = 1;

		service.writeReply(replyID, bbsID, replyContent, userID, replyDate, replyAvailable);

		return "redirect:detail?bbsID="+bbsID;
	}
}
