package com.bbs.web.Controller.WriteController;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bbs.web.Service.BbsService;

@Controller
public class WriteController {

	@Autowired
	private BbsService service;

	@GetMapping("Write")
	public String Write(Model model, HttpServletRequest request) {

		String result = null;
		String checkSession =(String) request.getSession().getAttribute("userid");
		if(checkSession != null) {
			model.addAttribute("check", checkSession);
		}else {
			result = "Home";
			boolean loginStatus = false;
			model.addAttribute("loginStatus", loginStatus);
		}
		return result;
	}

	
	@PostMapping("Write")
	public String WritetoDB(Model model, HttpServletRequest request, @RequestParam(value="userID", required = true) String userID
			, @RequestParam(value="bbsTitle", required = true) String bbsTitle, @RequestParam(value="bbsContent", required = true) String bbsContent
			) {

		String checkSession =(String) request.getSession().getAttribute("userid");
		if(checkSession != null) {
			model.addAttribute("check", checkSession);
		}
		
		Date bbsDate1 =  new Date();
		String pattern = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat formatter = new SimpleDateFormat(pattern);
		String bbsDate = formatter.format(bbsDate1);

		int bbsID = service.getBbsID();

		service.write(bbsID,bbsTitle,userID,bbsDate,bbsContent);

		return "redirect:Bbs";
	}


}
