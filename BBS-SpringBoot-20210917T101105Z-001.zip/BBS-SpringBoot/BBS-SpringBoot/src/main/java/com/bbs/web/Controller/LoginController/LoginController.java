package com.bbs.web.Controller.LoginController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bbs.web.Entity.User.User;
import com.bbs.web.Service.UserService;

@Controller
public class LoginController {

	@Autowired
	private UserService userService;
	@Autowired
	private User user;

	@PostMapping("LoginController")
	public String Login(Model model, HttpServletRequest request,
			@RequestParam(value = "userid", required = true) String userID,
			@RequestParam(value = "userpassword", required = true) String userPassword) {

		String result = null;
		user = userService.Login(userID, userPassword);

		if (user != null) {

			//세션에 아이디 저장 - 데이터 베이스(스프링이 테이블 자동으로 만듬)에 session 저장
			HttpSession session = request.getSession(); 
			session.setAttribute("userid", userID); 
			String checkSession = (String)
					request.getSession().getAttribute("userid");

			//성공시 view에서 alert를 위한 model
			System.out.println("login Okay");
			String loginokay = "okay";
			model.addAttribute("loginokay", loginokay);
			model.addAttribute("check", checkSession);

			result = "Home";
		} else {
			//실패시 view에서 alert를 위한 model
			String alert = ("다시 시도해 주세요");
			System.out.println("Login fail");
			model.addAttribute("alert", alert);

			result = "Login";
		}
		return result;

	}

}
