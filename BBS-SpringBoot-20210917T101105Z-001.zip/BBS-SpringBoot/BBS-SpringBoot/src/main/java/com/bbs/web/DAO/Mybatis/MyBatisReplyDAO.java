package com.bbs.web.DAO.Mybatis;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bbs.web.DAO.ReplyDAO;
import com.bbs.web.Entity.Reply;

@Repository
public class MyBatisReplyDAO implements ReplyDAO{

	private ReplyDAO mapper;
	
	@Autowired
	public MyBatisReplyDAO(SqlSession sqlSession) {
		mapper =sqlSession.getMapper(ReplyDAO.class);
	}
	
	
	@Override
	public ArrayList<Reply> getList(int bbsID, int limit) {
		// TODO Auto-generated method stub
		
		return mapper.getList(bbsID, limit);
	}

	@Override
	public int countReply(int bbsID) {
		// TODO Auto-generated method stub
		return mapper.countReply(bbsID);
	}

	@Override
	public int writeReply(int replyID, int bbsID, String replyContent, String userID, String replyDate,
			int replyAvailable) {
		// TODO Auto-generated method stub
		return mapper.writeReply(replyID, bbsID, replyContent, userID, replyDate, replyAvailable);
	}

	@Override
	public int deleteReply(int replyID) {
		// TODO Auto-generated method stub
		return mapper.deleteReply(replyID);
	}

	@Override
	public int updateReply(int replyID, String updateContent) {
		// TODO Auto-generated method stub
		return mapper.updateReply(replyID, updateContent);
	}

	@Override
	public Reply getReply(int replyID) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public int getReplyID() {
		// TODO Auto-generated method stub
		return mapper.getReplyID();
	}

}
