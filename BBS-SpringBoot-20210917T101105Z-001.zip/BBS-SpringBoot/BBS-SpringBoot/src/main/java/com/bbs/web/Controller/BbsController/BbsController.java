package com.bbs.web.Controller.BbsController;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bbs.web.Entity.Bbs;
import com.bbs.web.Service.BbsService;

@Controller
public class BbsController {
	@Autowired
	private BbsService service;
	// 상단 네비게이션 바를 통해서 들어올 때
	@GetMapping("Bbs")
	public String Bbs(Model model, HttpServletRequest request,
			@RequestParam(value = "pageNumber", defaultValue = "1", required = false) int pageNumber1,
			@RequestParam(value = "field", defaultValue = "bbsDate", required = false) String field,
			@RequestParam(value = "searchWord", defaultValue = "", required = false) String searchWord,
			@RequestParam(value = "sortType", defaultValue = "DESC", required = false) String sortType) {
		//세션
		String checkSession = (String) request.getSession().getAttribute("userid");
		if (checkSession != null) {
			model.addAttribute("check", checkSession);
		}
		int limit = 5;
		int pageNumber3 = ((pageNumber1 - 1) * 5);

		ArrayList<Bbs> list = service.getList(field, pageNumber3, limit, sortType, searchWord);

		int total = 0;
		total = service.count(field, searchWord);

		int totalPage = 0;

		if (total % 5 == 0) {
			totalPage = total / 5;
		} else {
			totalPage = total / 5 + 1;
		}
		// 글 목록
		ArrayList<Integer> realHeader = service.getheader(pageNumber1);
		//글 번호
		ArrayList<Integer> paging = service.buttonPaging(pageNumber1);

		model.addAttribute("pageNumber", pageNumber1);
		model.addAttribute("field", field);
		model.addAttribute("sortType", sortType);
		model.addAttribute("list", list);
		model.addAttribute("searchWord", searchWord);
		model.addAttribute("total", total);
		model.addAttribute("totalPage", totalPage);
		model.addAttribute("realHeader", realHeader);
		model.addAttribute("paging", paging);

		return "Bbs";
	}

	@PostMapping("Bbs")
	public String searchBbs(Model model, HttpServletRequest request,
			@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber1,
			@RequestParam(value = "sorts", required = true) String needTrim,
			@RequestParam(value = "searchWord", required = false, defaultValue = "") String searchWord) {

		//세션
		String checkSession = (String) request.getSession().getAttribute("userid");
		if (checkSession != null) {
			model.addAttribute("check", checkSession);
		}

		int limit = 5;
		int pageNumber = ((pageNumber1 - 1) * 5);

		String[] list2 = needTrim.split(",");
		String field = list2[0];
		String sortType = list2[1];

		ArrayList<Bbs> list = service.getList(field, pageNumber, limit, sortType, searchWord);
		int total = service.count(field, searchWord);
		ArrayList<Integer> realHeader = service.getheader(pageNumber1);
		ArrayList<Integer> paging = service.buttonPaging(pageNumber1);

		int totalPage = 0;

		if (total % 5 == 0) {
			totalPage = total / 5;
		} else {
			totalPage = total / 5 + 1;
		}

		if (list.isEmpty()) {
			String nosuch = "nosuch";
			model.addAttribute("nosuch", nosuch);
		}

		model.addAttribute("list", list);
		model.addAttribute("field", field);
		model.addAttribute("pageNumber", pageNumber1);
		model.addAttribute("sortType", sortType);
		model.addAttribute("searchWord", searchWord);
		model.addAttribute("total", total);
		model.addAttribute("totalPage", totalPage);
		model.addAttribute("realHeader", realHeader);
		model.addAttribute("paging", paging);

		return "Bbs";
	}

}
