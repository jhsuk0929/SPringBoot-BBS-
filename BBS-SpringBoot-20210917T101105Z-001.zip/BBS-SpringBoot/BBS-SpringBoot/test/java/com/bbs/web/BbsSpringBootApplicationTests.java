package com.bbs.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BbsSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
